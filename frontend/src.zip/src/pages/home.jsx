import React from 'react'
import Navbar from '../components/navbar'
import axios from 'axios'
import { useState, useRef } from 'react';

function Home() {

  const [file, setFile] = useState(null);
  const [text, settext] = useState('');
  const [isLoading, setisLoading] = useState(false);
  const [task, settask] = useState('upload');



  const [recording, setRecording] = useState(false);
    // const [transcription, setTranscription] = useState("");
    const mediaRecorderRef = useRef(null);
    const audioChunksRef = useRef([]);

    const startRecording = async () => {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorderRef.current = new MediaRecorder(stream);
        audioChunksRef.current = [];

        mediaRecorderRef.current.ondataavailable = (event) => {
            audioChunksRef.current.push(event.data);
        };

        mediaRecorderRef.current.onstop = () => {
    // Check if we actually have data
    if (audioChunksRef.current.length === 0) {
        console.error("No audio chunks recorded.");
        return;
    }

    // Combine chunks into a single Blob
    const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });

    // Verify it is a Blob before sending
    if (audioBlob instanceof Blob) {
        sendAudioToBackend(audioBlob);
    } else {
        console.error("The recorded data is not a valid Blob.");
    }
};

        mediaRecorderRef.current.start();
        setRecording(true);
    };

    const stopRecording = () => {
        mediaRecorderRef.current.stop();
        setRecording(false);
    };

    const sendAudioToBackend = async (blob) => {
        setisLoading(true)
        const formData = new FormData();
        // 'myfile' must match the name in your backend upload.single('myfile')
        formData.append('myfile', blob, 'recording.webm');

        try {
            // setTranscription("Processing...");
            const response = await axios.post('http://localhost:5000/file/upload', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            settext(response.data.transcription)
      setisLoading(false)
        } catch (error) {
            console.error("Error uploading audio:", error);
            // setTranscription("Error transcribing audio.");
            settext("Error in transcribing audio")
      setisLoading(false)
        }
    };







  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    setisLoading(true)
    if (!file) {
      alert("Please select a file first");
      return;
    }

    const formData = new FormData();
    formData.append("myfile", file);

    try {
      const response = await axios.post(
        "http://localhost:5000/file/upload",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log("Upload success:", response.data);
      settext(response.data.transcription)
      setisLoading(false)
    } catch (error) {
      console.error("Upload failed:", error);
      setisLoading(false)
    }
  };

  return (
    <>
    <Navbar/>

<form>
  <div class="space-y-12 m-20">
    <div class="border-white/10">
      <h2 class="mb-3 text-lg text-gray-400">Upload File or record it</h2>

        <div class="col-span-full">
          <div class="flex gap-2">
          <button class="mt-2 mb-2 rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500" onClick={()=>{settask('upload'); settext('')}}>Upload</button>
          <button class="mt-2 mb-2 rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500" onClick={()=>{settask('record'); settext('')}}>Record</button>
          </div>
          <div class="flex">

           {task==="upload" && <>
           <div class="mt-2 w-100 flex justify-center gap-0 rounded-lg border border-dashed border-white px-6 py-10">
            <div class="text-center">
              <div class="mt-4 flex text-sm/6 text-gray-400">
            <input onChange={handleFileChange} type="file" class="
            text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-full file:border-0
            file:text-sm file:font-semibold
            file:bg-blue-50 file:text-blue-700
            hover:file:bg-blue-100
            "/>
              </div>
            <button class="mt-5 rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500" onClick={handleUpload}>Upload</button>
            </div>
          </div>
           </>} 
          
          {task==="record" && <>
          <div class="mt-2 w-100 flex justify-center gap-0 rounded-lg border border-dashed border-white px-6 py-10">
            <div class="text-center">
              <button class="
            mr-4 py-2 px-4
            rounded-full border-0
            text-sm font-semibold
            bg-blue-50 text-blue-700
            hover:bg-blue-100
            " onClick={recording ? stopRecording : startRecording}>
                {recording ? "Stop Recording" : "Start Recording"}
            </button>
            </div>
          </div>
          </>}

          {isLoading===true && <>
<div class="mx-auto w-full max-w-sm rounded-md border border-blue-300 p-4">
  <div class="flex animate-pulse space-x-4">
    <div class="flex-1 space-y-6 py-1">
      <div class="space-y-3">
        <div class="h-2 rounded bg-gray-200"></div>
        <div class="h-2 rounded bg-gray-200"></div>
        <div class="h-2 rounded bg-gray-200"></div>
      </div>
    </div>
  </div>
</div>
</>}
    
{isLoading===false && <>

    <div class="mx-auto w-full max-w-sm rounded-md border border-blue-300 p-2">
  <div class="flex space-x-4">
    <div class="flex-1 space-y-6 p-3">
      <div class="space-y-3">{text}
      </div>
    </div>
  </div>
</div>
    </>
}

        </div>
      </div>
    </div>



</div>

</form>





    </>
  )
}

export default Home